<?php

define('__ROOT__', dirname(dirname(__FILE__)));

require_once('/var/www/html/env.php');

$requestMethod = $_SERVER['REQUEST_METHOD'];

$subpaths = array_filter(explode('/', $_SERVER[REQUEST_URI]));
$path_strip = preg_replace('/\?_=(\d+)/i', '', $subpaths['3']);
$mac_address = preg_replace('/\?_=(\d+)/i', '', $subpaths['4']);
$account = $path_strip ;

$output = file_get_contents('/var/www/html/provisioner/api/macaddress/' . $mac_address .'.json');
$output_devices = file_get_contents('/var/www/html/provisioner/api/devices/' . $account  . '/devices.json');


//$json = json_decode(file_get_contents("php://input"),true);
$dbconn = "postgres://" . $user . ":" . $password . "@" . $host . "/" . $database . "?sslmode=require" ;


$device_uuid = preg_replace("/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/i", "$1-$2-$3-$4-$5", $path_strip);

$auth_doc = '{
  "data": {
      "credentials": "'. $credentials .'",
      "account_name": "master"
  }
}';

$sql_device = "SELECT device_uuid FROM v_devices WHERE device_address='". $mac_address ."';";
$device_uuid = shell_exec("sudo psql -qtAX -d " . '"' . $dbconn . '" -c ' . '"' . $sql_device . '"'  );
$device_id = str_replace('-','', $device_uuid);

$cmd_json_auth= 'curl -s -H "Content-Type: application/json" -X PUT ' . $otf_conn . 'user_auth -d ' . "'" . $auth_doc . "'" ;
$json_auth = json_decode(shell_exec($cmd_json_auth),true);
$cmd_json_get= 'curl -s -H "Content-Type: application/json" -H "X-Auth-Token: '. $json_auth['auth_token']. '" -X GET ' . $otf_conn . 'accounts/' . $account ;
$cmd_json_get_devices = 'curl -s -H "Content-Type: application/json" -H "X-Auth-Token: '. $json_auth['auth_token']. '" -X GET ' . $otf_conn . 'accounts/' . $account . '/devices/' ;
$cmd_json_get_device = 'curl -s -H "Content-Type: application/json" -H "X-Auth-Token: '. $json_auth['auth_token']. '" -X GET ' . $otf_conn . 'accounts/' . $account . '/devices/' . $device_id . '/ | python3 -mjson.tool';
$device = shell_exec($cmd_json_get_device );

if ($requestMethod === 'GET') {
$sql_device = "SELECT device_uuid FROM v_devices WHERE device_address='". $mac_address ."';";
$device_uuid = shell_exec("sudo psql -qtAX -d " . '"' . $dbconn . '" -c ' . '"' . $sql_device . '"'  );
$device_id = str_replace('-','', $device_uuid);

$devices = json_decode($output,true) ;

header('Content-Type: application/json');
$result = json_encode($devices,true) ;

$cmd = shell_exec('echo ' . $result  . ' | python3 -mjson.tool');

print_r($result) ;




//$sql_device = "SELECT domain_uuid FROM v_devices WHERE device_uuid='". $device_uuid ."';";
//$account = shell_exec("sudo psql -qtAX -d " . '"' . $dbconn . '" -c ' . '"' . $sql_device . '"'  );

//file_put_contents("/var/www/html/provisioner.log",print_r($cmd_json_get_device,true),FILE_APPEND);

} elseif ($requestMethod === 'POST') {

$input  = file_get_contents('php://input');
$json = json_decode(print_r($input,true),true);
$mac = $json['data']['mac_address'];
$originalJson = $output ;


$postdoc = json_encode($json,true);

$cmd_json_post_dev = file_put_contents('/var/www/html/provisioner/api/macaddress/' . $mac . '.json',  $postdoc) ;

file_put_contents("/var/www/html/provisioner-post.log",print_r($postdoc,true),FILE_APPEND);

$decodedData = json_decode($originalJson,true);

$newData  = [ "mac_address" =>  $putdoc_arr['data']['mac_address'] , "name" =>  $putdoc_arr['data']['name'] , "brand" =>  $putdoc_arr['data']['brand'] , "family" =>   $putdoc_arr['data']['family']  , "model" =>  $putdoc_arr['data']['model'], "settings" => $putdoc_arr['data']['settings']   ];

$decodedData['data'][] = $newData  ;

$modifiedJson = json_encode($decodedData,true);


} elseif ($requestMethod === 'PUT') {
$input  = file_get_contents('php://input');
$json = json_decode(print_r($input,true),true);
$mac = $json['data']['mac_address'];

$putdoc = json_encode($json);

$cmd_json_put_dev = file_put_contents('/var/www/html/provisioner/api/macaddress/' . $mac . '.json',  $putdoc) ;

$putdoc_arr = json_decode($putdoc,true);
//$putdoc_dev_arr = json_decode($output_devices,true);

$originalJson =   $output_devices  ;

$decodedData = json_decode($originalJson,true);

$newData  = [ "mac_address" =>  $putdoc_arr['data']['mac_address'] , "name" =>  $putdoc_arr['data']['name'] , "brand" =>  $putdoc_arr['data']['brand'] , "family" =>   $putdoc_arr['data']['family']  , "model" =>  $putdoc_arr['data']['model']   ];

$decodedData['data'][] = $newData  ;

$modifiedJson = json_encode($decodedData,true);

//shell_exec($cmd_json_put_dev); 
$lsddir = '/var/www/html/provisioner/api/devices/' . $account . '/' ;
/*
if(!file_exists($lsddir)) { 
  shell_exec('mkdir -p ' . $lsddir);
}
*/


file_put_contents($lsddir .'devices.json', $modifiedJson);


$originalJsonDev = '{ "data":{}}' ;
//$originalJsonDev = $output ;

$dev_decodedData = json_decode($originalJsonDev,true);
$dev_newData = ['mac_address' => $putdoc_arr['data']['mac_address'], "name" => $putdoc_arr['data']['name']];
$dev_prov_newData = [ 'endpoint_brand' => $putdoc_arr['data']['brand'], 'endpoint_family' => $putdoc_arr['data']['family'], 'endpoint_model' => $putdoc_arr['data']['model'] ];

$dev_decodedData['data'] = $dev_newData;
$dev_decodedData['data']['provision'] = $dev_prov_newData;

$modifiedJsonDev = json_encode($dev_decodedData,true);

$cmd_put_devices= 'curl -s -H "Content-Type: application/json" -H "X-Auth-Token: '. $json_auth['auth_token']. '" -X PUT  ' . $otf_conn . 'accounts/' . $account . '/devices/' . ' -d ' . "'" . $modifiedJsonDev . "'"  ;

file_put_contents("/var/www/html/provisioner-put.log",print_r($cmd_put_devices,true),FILE_APPEND);
shell_exec($cmd_put_devices); 

} elseif ($requestMethod === 'DELETE') {
$sql_device = "SELECT device_uuid FROM v_devices WHERE device_address='". $mac_address ."';";
$device_uuid = shell_exec("sudo psql -qtAX -d " . '"' . $dbconn . '" -c ' . '"' . $sql_device . '"'  );
$device_id = str_replace('-','', $device_uuid);

$cmd_json_delete_dev= 'curl -s -H "Content-Type: application/json" -H "X-Auth-Token: '. $json_auth['auth_token']. '" -X DELETE  ' . $otf_conn . 'accounts/' . $account . '/devices/' . $device_id  ;
shell_exec($cmd_json_delete_dev); 
} else {
    echo "This is an unsupported request method: " . $requestMethod;
}



