<?php
/**
 * Snom 320, 360, 370 with Exp.Module Provisioning System
 *
 * @author Corrado Mella
 * @license MPL / GPLv2 / LGPL
 * @package Provisioner
 */
class endpoint_snom_3xxEM_phone extends endpoint_snom_base {

	public $family_line = '3xxEM';
	
}
