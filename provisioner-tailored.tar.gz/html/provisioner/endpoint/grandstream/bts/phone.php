<?php
/**
 * Grandstream BTS Phone File
 *
 * @author Andrew Nagy
 * @license MPL / GPLv2 / LGPL
 * @package Provisioner
 */
class endpoint_grandstream_bts_phone extends endpoint_grandstream_base {
	public $family_line = 'bts';

}

?>
