<?php

class provisionerTest extends PHPUnit_Framework_TestCase {
    public function testLoader() {
        return True;
    }
}